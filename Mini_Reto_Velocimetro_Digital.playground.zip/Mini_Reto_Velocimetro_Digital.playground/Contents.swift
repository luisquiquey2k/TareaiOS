//: Velocimetro digital

import UIKit

//Declaracion de una enumeracion
enum Velocidades : Int{
	case Apagado = 0, VelocidadBaja = 20, VelocidadMedia = 50, VelocidadAlta = 120
	
	init(velocidadInicial : Velocidades){
		self = velocidadInicial
	}
}

//Creacion de una clase
class Auto{

	//Instancia
	var velocidad : Velocidades
	
	//Declaracion de atributos
	var actual : Int = 0
	var velocidadEnCadena : String = ""
	
	init(velocidad: Velocidades){
		self.velocidad
	}
}



