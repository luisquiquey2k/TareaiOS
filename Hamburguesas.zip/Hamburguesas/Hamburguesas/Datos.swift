//
//  Datos.swift
//  Hamburguesas
//
//  Created by Luis Enrique Velazquez Perea on 17/06/16.
//  Copyright © 2016 Luis Enrique Velazquez Perea. All rights reserved.
//

import Foundation

import UIKit

//Clase para paises
class ColeccionDePaises{
	
	//Declaracion de un arreglo de paises
	let paises = ["🇲🇽Mexico", "🇺🇸Estados Unidos", "🇨🇦Canada", "🇦🇷Argentina", "🇧🇷Brazil", "🇨🇴Colombia", "🇺🇾Uruguay", "🇪🇸España", "🇩🇪Alemania", "🇮🇹Italia", "🇫🇷Francia", "🇵🇹Portugal", "🇬🇧Inglaterra", "🇨🇭Suiza", "🇳🇴Noruega", "🇬🇷Grecia", "🇷🇴Rumania", "🇳🇱Holanda", "🇯🇵Japon", "🇰🇷Corea"]
	
	//Creacion de la funcion
	func obtenPais() -> String {
		let posicion = Int (arc4random()) % paises.count
		return paises[posicion]
	}
}

class ColeccionDeHamburguesas{
	
	//Declaracion de un arreglo de hamburguesas
	let hamburguesas = ["🍔Hamburguesa Hawaiana", "🍔Hamburguesa a la parrilla", "🍔Hamburguesa a las brazas", "🍔Hamburguesa de tofu","🍔Hamburguesa de pescado","🍔Hamburguesa de pollo","🍔Hamburguesa de soya","🍔Hamburguesa de atun","🍔Hamburguesa de salmon", "🍔Hamburguesa de verduras", "🍔Hamburguesa doble carne","🍔Hamburguesa BBQ","🍔Hamburguesa de garbanzos","🍔Hamburguesa de espinacas", "🍔Hamburguesa de pavo", "🍔Hamburguesa de conejo", "🍔Hamburguesa de lentejas", "🍔Hamburguesa Thermomix","🍔Hamburguesa con huevo","🍔Hamburguesa de ternera"]
	
	//Creacion de una funcion
	func obtenHamburguesa() -> String {
		let posicion = Int (arc4random()) % hamburguesas.count
		return hamburguesas[posicion]
	}
}


//Estructura para crear colores
struct Colores{
	
	let colores = [ UIColor(red:210/255.0, green: 90/255.0, blue: 45/255.0, alpha: 1),
	                
	                UIColor(red:40/255.0, green: 170/255.0, blue: 45/255.0, alpha: 1),
	                
	                UIColor(red:3/255.0, green: 180/255.0, blue: 90/255.0, alpha: 1),
	                
	                UIColor(red:210/255.0, green: 190/255.0, blue: 5/255.0, alpha: 1),
	                
	                UIColor(red:120/255.0, green: 120/255.0, blue: 50/255.0, alpha: 1),
	                
	                UIColor(red:130/255.0, green: 80/255.0, blue: 90/255.0, alpha: 1),
	                
	                UIColor(red:130/255.0, green: 130/255.0, blue: 130/255.0, alpha: 1),
	                
	                UIColor(red:3/255.0, green: 50/255.0, blue: 90/255.0, alpha: 1)]
	
	//Funcion que regresa un color aleatorio
	func regresaColorAleatorio() -> UIColor {
		let posicion = Int (arc4random()) % colores.count
		return colores[posicion]
	}
}
