//
//  ViewController.swift
//  Hamburguesas
//
//  Created by Luis Enrique Velazquez Perea on 17/06/16.
//  Copyright © 2016 Luis Enrique Velazquez Perea. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

	
	@IBOutlet weak var dameUnPais: UILabel!
	let paises = ColeccionDePaises()
	
	
	@IBOutlet weak var tipoDeHamburguesa: UILabel!
	let hamburguesas = ColeccionDeHamburguesas()

	
	override func viewDidLoad() {
		super.viewDidLoad()
		// Do any additional setup after loading the view, typically from a nib.
	}

	override func didReceiveMemoryWarning() {
		super.didReceiveMemoryWarning()
		// Dispose of any resources that can be recreated.
	}

	@IBAction func dameUnaHamburguesa() {
		dameUnPais.text = paises.obtenPais()
		tipoDeHamburguesa.text = hamburguesas.obtenHamburguesa()
		
		//cambio de color aleatorio
		let colores = Colores()
		let colorAleatorio = colores.regresaColorAleatorio()
		view.backgroundColor = colorAleatorio	//Asignacion a la vista (fondo)
		view.tintColor = colorAleatorio			//Asignacion a la vista (color activo)
	
	}

}

